import React from 'react';
import { ExternalLink, Github, Calendar, Tag } from 'lucide-react';

const Projects: React.FC = () => {
  const projects = [
    {
      title: 'E-Commerce Website',
      description: 'A full-stack e-commerce platform built as a college project with React frontend and Node.js backend. Features include product catalog, shopping cart, and user authentication.',
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg',
      technologies: ['React', 'Node.js', 'MySQL', 'Express.js', 'CSS'],
      githubUrl: 'https://github.com',
      liveUrl: 'https://example.com',
      date: '2024',
      featured: true
    },
    {
      title: 'Task Management App',
      description: 'A personal project management tool with drag-and-drop functionality. Built to learn React hooks and state management with local storage persistence.',
      image: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg',
      technologies: ['React', 'JavaScript', 'CSS', 'Local Storage'],
      githubUrl: 'https://github.com',
      liveUrl: 'https://example.com',
      date: '2024',
      featured: true
    },
    {
      title: 'Weather App',
      description: 'A responsive weather application that fetches data from OpenWeather API. Features current weather, 5-day forecast, and location-based search.',
      image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg',
      technologies: ['JavaScript', 'HTML', 'CSS', 'Weather API'],
      githubUrl: 'https://github.com',
      liveUrl: 'https://example.com',
      date: '2023',
      featured: false
    },
    {
      title: 'Student Portal',
      description: 'A college project for student management system with features like attendance tracking, grade management, and course enrollment.',
      image: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg',
      technologies: ['PHP', 'MySQL', 'Bootstrap', 'JavaScript'],
      githubUrl: 'https://github.com',
      liveUrl: 'https://example.com',
      date: '2023',
      featured: false
    },
    {
      title: 'Recipe Finder',
      description: 'A web application to search and discover recipes using TheMealDB API. Includes recipe details, ingredients list, and cooking instructions.',
      image: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg',
      technologies: ['React', 'API Integration', 'CSS', 'JavaScript'],
      githubUrl: 'https://github.com',
      liveUrl: 'https://example.com',
      date: '2023',
      featured: false
    },
    {
      title: 'Portfolio Website',
      description: 'My personal portfolio website showcasing projects and skills. Built with React and Tailwind CSS with responsive design and smooth animations.',
      image: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg',
      technologies: ['React', 'Tailwind CSS', 'JavaScript', 'Responsive Design'],
      githubUrl: 'https://github.com',
      liveUrl: 'https://example.com',
      date: '2024',
      featured: false
    }
  ];

  const featuredProjects = projects.filter(p => p.featured);
  const otherProjects = projects.filter(p => !p.featured);

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              My Projects
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-emerald-400 to-teal-400 mx-auto rounded-full"></div>
          <p className="text-gray-400 mt-6 max-w-2xl mx-auto">
            A collection of academic projects and personal work that showcase my learning journey and technical skills.
          </p>
        </div>

        {/* Featured Projects */}
        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          {featuredProjects.map((project, index) => (
            <div
              key={index}
              className="group bg-gray-800/50 rounded-xl overflow-hidden border border-gray-700/50 hover:border-emerald-400/30 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-500/10"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-transparent to-transparent"></div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-semibold text-gray-100 group-hover:text-emerald-400 transition-colors">
                    {project.title}
                  </h3>
                  <div className="flex items-center text-gray-400 text-sm">
                    <Calendar size={14} className="mr-1" />
                    {project.date}
                  </div>
                </div>
                
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.technologies.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-3 py-1 bg-gray-700/50 text-emerald-400 rounded-full text-xs font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                <div className="flex gap-4">
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 bg-gray-700/50 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors text-sm"
                  >
                    <Github size={16} />
                    Code
                  </a>
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 rounded-lg transition-colors text-sm"
                  >
                    <ExternalLink size={16} />
                    Live Demo
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Other Projects Grid */}
        <div className="mb-8">
          <h3 className="text-2xl font-semibold text-gray-100 mb-8 text-center">
            Other Projects
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {otherProjects.map((project, index) => (
              <div
                key={index}
                className="group bg-gray-800/30 rounded-lg p-6 border border-gray-700/50 hover:border-emerald-400/30 transition-all duration-300 hover:shadow-lg hover:shadow-emerald-500/10"
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-lg font-semibold text-gray-100 group-hover:text-emerald-400 transition-colors">
                    {project.title}
                  </h4>
                  <span className="text-gray-400 text-xs">{project.date}</span>
                </div>
                
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {project.technologies.slice(0, 3).map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-2 py-1 bg-gray-700/30 text-emerald-400 rounded text-xs"
                    >
                      {tech}
                    </span>
                  ))}
                  {project.technologies.length > 3 && (
                    <span className="px-2 py-1 text-gray-500 text-xs">
                      +{project.technologies.length - 3} more
                    </span>
                  )}
                </div>
                
                <div className="flex gap-3">
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-emerald-400 transition-colors"
                  >
                    <Github size={18} />
                  </a>
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-emerald-400 transition-colors"
                  >
                    <ExternalLink size={18} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* View More Projects Button */}
        <div className="text-center">
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-full font-medium hover:shadow-lg hover:shadow-emerald-500/25 transition-all duration-300 hover:scale-105"
          >
            <Github size={20} />
            View All Projects on GitHub
          </a>
        </div>
      </div>
    </section>
  );
};

export default Projects;