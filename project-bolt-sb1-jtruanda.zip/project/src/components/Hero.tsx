import React from 'react';
import { ChevronDown, Github, Linkedin, Mail } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with panda image */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900/90 via-gray-900/80 to-gray-900/90 z-10"></div>
        <img
          src="https://images.pexels.com/photos/3608263/pexels-photo-3608263.jpeg"
          alt="Panda background"
          className="w-full h-full object-cover opacity-30"
        />
      </div>

      {/* Hero content */}
      <div className="relative z-20 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="animate-fade-in-up">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent">
              Anshika Pawar
            </span>
          </h1>
          
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-light text-gray-300 mb-8">
            Full-Stack Developer
          </h2>
          
          <p className="text-lg sm:text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed">
            Fresh graduate passionate about creating innovative digital solutions. 
            Eager to apply modern technologies and contribute to meaningful projects.
          </p>

          {/* Social links */}
          <div className="flex justify-center space-x-6 mb-12">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-gray-800/50 hover:bg-emerald-500/20 rounded-full transition-all duration-300 hover:scale-110 group"
            >
              <Github size={24} className="text-gray-400 group-hover:text-emerald-400 transition-colors" />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-gray-800/50 hover:bg-blue-500/20 rounded-full transition-all duration-300 hover:scale-110 group"
            >
              <Linkedin size={24} className="text-gray-400 group-hover:text-blue-400 transition-colors" />
            </a>
            <a
              href="mailto:anshikapawar68@gmail.com"
              className="p-3 bg-gray-800/50 hover:bg-purple-500/20 rounded-full transition-all duration-300 hover:scale-110 group"
            >
              <Mail size={24} className="text-gray-400 group-hover:text-purple-400 transition-colors" />
            </a>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={scrollToAbout}
              className="px-8 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-full font-medium hover:shadow-lg hover:shadow-emerald-500/25 transition-all duration-300 hover:scale-105"
            >
              Learn More About Me
            </button>
            <button
              onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-3 border border-emerald-400 text-emerald-400 rounded-full font-medium hover:bg-emerald-400 hover:text-gray-900 transition-all duration-300"
            >
              View My Work
            </button>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 animate-bounce"
      >
        <ChevronDown size={32} className="text-emerald-400" />
      </button>
    </section>
  );
};

export default Hero;