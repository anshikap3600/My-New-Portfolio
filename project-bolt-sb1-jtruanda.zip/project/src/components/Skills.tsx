import React from 'react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      title: 'Frontend',
      skills: [
        { name: 'React/Next.js', level: 80 },
        { name: 'JavaScript', level: 85 },
        { name: 'HTML/CSS', level: 90 },
        { name: 'Tailwind CSS', level: 75 }
      ]
    },
    {
      title: 'Backend',
      skills: [
        { name: 'Node.js', level: 70 },
        { name: 'Python', level: 75 },
        { name: 'MySQL', level: 80 },
        { name: 'MongoDB', level: 65 }
      ]
    },
    {
      title: 'Tools & Others',
      skills: [
        { name: 'Git/GitHub', level: 85 },
        { name: 'VS Code', level: 90 },
        { name: 'Postman', level: 75 },
        { name: 'Figma', level: 60 }
      ]
    }
  ];

  const tools = [
    'React', 'JavaScript', 'Node.js', 'Python', 'MySQL', 'MongoDB',
    'HTML', 'CSS', 'Tailwind CSS', 'Git', 'GitHub', 'VS Code',
    'Postman', 'Figma', 'Bootstrap', 'Express.js', 'REST APIs', 'JSON'
  ];

  return (
    <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-800/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              Skills & Technologies
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-emerald-400 to-teal-400 mx-auto rounded-full"></div>
          <p className="text-gray-400 mt-6 max-w-2xl mx-auto">
            Technologies and tools I've learned through academic projects and personal development.
          </p>
        </div>

        {/* Skill Categories */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="bg-gray-800/50 rounded-xl p-6 border border-gray-700/50 hover:border-emerald-400/30 transition-all duration-300"
            >
              <h3 className="text-xl font-semibold text-emerald-400 mb-6 text-center">
                {category.title}
              </h3>
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-300 font-medium text-sm">
                        {skill.name}
                      </span>
                      <span className="text-gray-400 text-xs">
                        {skill.level}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-emerald-400 to-teal-400 h-2 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Technologies & Tools */}
        <div className="text-center">
          <h3 className="text-2xl font-semibold text-gray-100 mb-8">
            Technologies & Tools
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            {tools.map((tool, index) => (
              <span
                key={index}
                className="px-4 py-2 bg-gray-800 text-gray-300 rounded-full text-sm font-medium border border-gray-700 hover:border-emerald-400/50 hover:text-emerald-400 transition-all duration-300 cursor-default"
              >
                {tool}
              </span>
            ))}
          </div>
        </div>

        {/* Education & Status */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center justify-center space-x-8 text-gray-400">
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">Fresh</div>
              <div className="text-sm">Graduate</div>
            </div>
            <div className="w-px h-12 bg-gray-700"></div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">CS</div>
              <div className="text-sm">Degree</div>
            </div>
            <div className="w-px h-12 bg-gray-700"></div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">15+</div>
              <div className="text-sm">Projects</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;