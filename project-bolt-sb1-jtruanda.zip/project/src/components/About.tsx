import React from 'react';
import { Code, Server, Database, Smartphone } from 'lucide-react';

const About: React.FC = () => {
  const highlights = [
    {
      icon: <Code size={24} />,
      title: 'Frontend Development',
      description: 'Building responsive, interactive user interfaces with React, TypeScript, and modern CSS frameworks.'
    },
    {
      icon: <Server size={24} />,
      title: 'Backend Development',
      description: 'Learning to build scalable APIs and server-side applications with Node.js, Python, and cloud technologies.'
    },
    {
      icon: <Database size={24} />,
      title: 'Database Design',
      description: 'Understanding database schemas and working with both SQL and NoSQL databases through academic projects.'
    },
    {
      icon: <Smartphone size={24} />,
      title: 'Mobile Development',
      description: 'Exploring cross-platform mobile development with React Native and modern app development practices.'
    }
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              About Me
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-emerald-400 to-teal-400 mx-auto rounded-full"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left column - Text content */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-gray-100 mb-6">
              Fresh Graduate Ready to Make an Impact
            </h3>
            
            <p className="text-gray-300 leading-relaxed">
              Hello! I'm Anshika, a passionate fresh graduate with a Computer Science degree 
              and a strong foundation in full-stack development. My journey in software 
              development has been driven by curiosity and a desire to create meaningful 
              digital solutions.
            </p>

            <p className="text-gray-300 leading-relaxed">
              During my academic journey, I've worked on various projects using React, Node.js, 
              and modern web technologies. I'm particularly interested in building user-friendly 
              applications that solve real-world problems and create positive user experiences.
            </p>

            <p className="text-gray-300 leading-relaxed">
              I'm eager to start my professional career and contribute to innovative projects. 
              I believe in continuous learning, staying updated with the latest technologies, 
              and collaborating with teams to build amazing products.
            </p>

            <div className="flex flex-wrap gap-3 mt-8">
              {['React', 'JavaScript', 'Node.js', 'Python', 'MySQL', 'Git', 'HTML/CSS', 'MongoDB'].map((tech) => (
                <span
                  key={tech}
                  className="px-4 py-2 bg-gray-800 text-emerald-400 rounded-full text-sm font-medium border border-emerald-400/20"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Right column - Highlights */}
          <div className="grid sm:grid-cols-2 gap-6">
            {highlights.map((highlight, index) => (
              <div
                key={index}
                className="p-6 bg-gray-800/50 rounded-xl border border-gray-700/50 hover:border-emerald-400/30 transition-all duration-300 hover:shadow-lg hover:shadow-emerald-500/10"
              >
                <div className="text-emerald-400 mb-4">
                  {highlight.icon}
                </div>
                <h4 className="text-lg font-semibold text-gray-100 mb-3">
                  {highlight.title}
                </h4>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {highlight.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Stats section */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { number: '15+', label: 'Academic Projects' },
            { number: 'Fresh', label: 'Graduate' },
            { number: '8+', label: 'Technologies Learned' },
            { number: '100%', label: 'Dedication' }
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl font-bold text-emerald-400 mb-2">
                {stat.number}
              </div>
              <div className="text-gray-400 text-sm">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;